﻿using CalculatorTest;

namespace M7Coverage
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Sumar_DosNumeros_RetornaCorrecto()
        {
            var calc = new Calculadora();
            int resultado = calc.Sumar(3, 2);

            Assert.AreEqual(5, resultado);
        }
    }
}
