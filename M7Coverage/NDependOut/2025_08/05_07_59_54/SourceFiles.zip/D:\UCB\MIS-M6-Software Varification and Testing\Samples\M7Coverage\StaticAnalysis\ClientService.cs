﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticAnalysis
{
    public class ClientService
    {
        public void addclient(string n, string d) 
        {
            
            Console.WriteLine("Cliente agregado: " + n);
        }
    }
}
