﻿namespace GeneralLibrary.IntegrationTest
{
    public class UsuarioIntegration
    {
        public string Nombre { get; set; }
        public string Email { get; set; }
    }
}   